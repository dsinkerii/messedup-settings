cd python-files
python host.py
cd ..