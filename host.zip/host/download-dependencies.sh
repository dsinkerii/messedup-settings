cd python-files
python main.py
cd ..
echo "Dependencies downloaded! You can now run:"
echo "\`gui.sh\`"